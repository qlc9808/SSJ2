# SHOPPER

Shopper Theme by Unvab Plus.

### Documentation

Documentation is available at `dist/docs/getting-started.html` or online at https://yevgenysim.github.io/shopper/docs/getting-started.html.

### Getting Started

Please follow the steps below to install the theme. Refer to the documentation for detailed instructions.

- npm install
- npm start

### Design Files

Please use the link below to download an "unofficial" Figma file:
https://drive.google.com/drive/folders/1yUk3r31xMkfB_J1SwAczGPdIqYtDbc5v?usp=sharing

### Support

Feel free to contact us via plus.unvab@gmail.com if you have any questions.
