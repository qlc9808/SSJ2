package com.oracle.S202350102;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class S202350102ApplicationTests {

	@Test
	void contextLoads() {
	}

}
