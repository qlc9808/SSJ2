package com.oracle.S202350102.service.chService;

import com.oracle.S202350102.dto.User1;

public interface ChUser1Service {

	int 	getUNum(String user_id);
	
}
