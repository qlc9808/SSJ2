package com.oracle.S202350102.dao.chDao;

import java.util.List;

import com.oracle.S202350102.dto.Challenge;

public interface ChChallengeDao {
	List<Challenge> popChgList();
}
