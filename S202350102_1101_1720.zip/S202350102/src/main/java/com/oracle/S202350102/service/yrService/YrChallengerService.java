package com.oracle.S202350102.service.yrService;

import java.util.List;

import com.oracle.S202350102.dto.Challenger;

public interface YrChallengerService {

	List<Challenger> 	getListSsj();

}
