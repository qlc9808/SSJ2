package com.oracle.S202350102.dao.yrDao;

public interface YrChallengerDao {

}
