package com.oracle.S202350102.dao.mainDao;

import com.oracle.S202350102.dto.User1;

public interface UserDao {

	User1 userSelect(String user_id);

}
