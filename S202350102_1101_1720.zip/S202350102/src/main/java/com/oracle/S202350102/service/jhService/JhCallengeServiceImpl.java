package com.oracle.S202350102.service.jhService;

import org.springframework.stereotype.Service;

import com.oracle.S202350102.dto.Challenge;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class JhCallengeServiceImpl implements JhCallengeService {
	
	
	@Override
	public Challenge jhChgDetail(Challenge chg_id) {
		return null;
	}
	

	
	

}
