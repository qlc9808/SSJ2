package com.oracle.S202350102.dao.yrDao;

public class YrChallengerDaoImpl implements YrChallengerDao {

}
