package com.oracle.S202350102.service.chService;

import java.util.List;

import com.oracle.S202350102.dto.Challenge;

public interface ChChallengeService {
	List<Challenge> popchgList();
}
