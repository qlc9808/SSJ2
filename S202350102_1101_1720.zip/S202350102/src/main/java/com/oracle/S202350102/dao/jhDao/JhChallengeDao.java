package com.oracle.S202350102.dao.jhDao;

public interface JhChallengeDao {

}
