package com.oracle.S202350102.service.yrService;

import java.util.List;

import org.springframework.stereotype.Service;

import com.oracle.S202350102.dto.Challenger;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class YrChallengerServiceImpl implements YrChallengerService {

	@Override
	public List<Challenger> getListSsj() {
		// TODO Auto-generated method stub
		return null;
	}

}
