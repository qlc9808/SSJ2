package com.oracle.S202350102.service.jhService;

import com.oracle.S202350102.dto.Challenge;

public interface JhCallengeService {

	Challenge jhChgDetail(Challenge chg_id);


}
