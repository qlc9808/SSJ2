package com.oracle.S202350102.service.main;

import com.oracle.S202350102.dto.User1;

public interface UserService {

	User1 userSelect(String user_id);
	
}
